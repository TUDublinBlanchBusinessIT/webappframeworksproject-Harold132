<!-- Bookingdate Field -->
<div class="form-group">
    {!! Form::label('bookingdate', 'Bookingdate:') !!}
    <p>{{ $booking->bookingdate }}</p>
</div>

<!-- Starttime Field -->
<div class="form-group">
    {!! Form::label('starttime', 'Starttime:') !!}
    <p>{{ $booking->starttime }}</p>
</div>

<!-- Endtime Field -->
<div class="form-group">
    {!! Form::label('endtime', 'Endtime:') !!}
    <p>{{ $booking->endtime }}</p>
</div>

<!-- Customerid Field -->
<div class="form-group">
    {!! Form::label('customerid', 'Customerid:') !!}
    <p>{{ $booking->customerid }}</p>
</div>

<!-- Carid Field -->
<div class="form-group">
    {!! Form::label('carid', 'Carid:') !!}
    <p>{{ $booking->carid }}</p>
</div>

<!-- Fee Field -->
<div class="form-group">
    {!! Form::label('fee', 'Fee:') !!}
    <p>{{ $booking->fee }}</p>
</div>

