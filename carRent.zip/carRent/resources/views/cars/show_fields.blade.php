<!-- Make Field -->
<div class="form-group">
    {!! Form::label('make', 'Make:') !!}
    <p>{{ $car->make }}</p>
</div>

<!-- Model Field -->
<div class="form-group">
    {!! Form::label('model', 'Model:') !!}
    <p>{{ $car->model }}</p>
</div>

<!-- Doors Field -->
<div class="form-group">
    {!! Form::label('doors', 'Doors:') !!}
    <p>{{ $car->doors }}</p>
</div>

