<!-- Firstname Field -->
<div class="form-group">
    {!! Form::label('firstname', 'Firstname:') !!}
    <p>{{ $customer->firstname }}</p>
</div>

<!-- Surname Field -->
<div class="form-group">
    {!! Form::label('surname', 'Surname:') !!}
    <p>{{ $customer->surname }}</p>
</div>

<!-- Customertype Field -->
<div class="form-group">
    {!! Form::label('customertype', 'Customertype:') !!}
    <p>{{ $customer->customertype }}</p>
</div>

<!-- Dateofbirth Field -->
<div class="form-group">
    {!! Form::label('dateofbirth', 'Dateofbirth:') !!}
    <p>{{ $customer->dateofbirth }}</p>
</div>

