<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model as Model;

/**
 * Class car
 * @package App\Models
 * @version April 11, 2020, 2:49 pm UTC
 *
 * @property \Illuminate\Database\Eloquent\Collection bookings
 * @property string make
 * @property string model
 * @property string doors
 */
class car extends Model
{

    public $table = 'car';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';




    public $fillable = [
        'make',
        'model',
        'doors'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'make' => 'string',
        'model' => 'string',
        'doors' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     **/
    public function bookings()
    {
        return $this->hasMany(\App\Models\Booking::class, 'carid');
    }
}
