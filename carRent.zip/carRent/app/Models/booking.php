<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model as Model;

/**
 * Class booking
 * @package App\Models
 * @version April 11, 2020, 2:59 pm UTC
 *
 * @property \App\Models\Customer customerid
 * @property \App\Models\Car carid
 * @property string bookingdate
 * @property time starttime
 * @property time endtime
 * @property integer customerid
 * @property integer carid
 * @property number fee
 */
class booking extends Model
{

    public $table = 'booking';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';




    public $fillable = [
        'bookingdate',
        'starttime',
        'endtime',
        'customerid',
        'carid',
        'fee'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'bookingdate' => 'date',
        'customerid' => 'integer',
        'carid' => 'integer',
        'fee' => 'float'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function customerid()
    {
        return $this->belongsTo(\App\Models\Customer::class, 'customerid');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function carid()
    {
        return $this->belongsTo(\App\Models\Car::class, 'carid');
    }
}
