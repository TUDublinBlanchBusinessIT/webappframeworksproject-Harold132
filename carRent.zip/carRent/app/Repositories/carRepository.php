<?php

namespace App\Repositories;

use App\Models\car;
use App\Repositories\BaseRepository;

/**
 * Class carRepository
 * @package App\Repositories
 * @version April 11, 2020, 2:49 pm UTC
*/

class carRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'make',
        'model',
        'doors'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return car::class;
    }
}
