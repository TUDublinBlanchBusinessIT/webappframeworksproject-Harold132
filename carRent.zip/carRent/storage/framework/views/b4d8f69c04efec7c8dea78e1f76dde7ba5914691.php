<!-- Firstname Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('firstname', 'Firstname:'); ?>

    <?php echo Form::text('firstname', null, ['class' => 'form-control']); ?>

</div>

<!-- Surname Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('surname', 'Surname:'); ?>

    <?php echo Form::text('surname', null, ['class' => 'form-control']); ?>

</div>

<!-- Customertype Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('customertype', 'Customertype:'); ?>

    <?php echo Form::text('customertype', null, ['class' => 'form-control']); ?>

</div>

<!-- Dateofbirth Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('dateofbirth', 'Dateofbirth:'); ?>

    <?php echo Form::date('dateofbirth', null, ['class' => 'form-control','id'=>'dateofbirth']); ?>

</div>



<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\Users\Haris\Desktop\USBWebserver v8.6\root\Laravel\carRent\resources\views/customers/fields.blade.php ENDPATH**/ ?>