<div class="table-responsive">
    <table class="table" id="customers-table">
        <thead>
            <tr>
                <th>Firstname</th>
        <th>Surname</th>
        <th>Customertype</th>
        <th>Dateofbirth</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($customer->firstname); ?></td>
            <td><?php echo e($customer->surname); ?></td>
            <td><?php echo e($customer->customertype); ?></td>
            <td><?php echo e($customer->dateofbirth); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['customers.destroy', $customer->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('customers.show', [$customer->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('customers.edit', [$customer->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\Haris\Desktop\USBWebserver v8.6\root\Laravel\carRent\resources\views/customers/table.blade.php ENDPATH**/ ?>