<div class="table-responsive">
    <table class="table" id="cars-table">
        <thead>
            <tr>
                <th>Make</th>
        <th>Model</th>
        <th>Doors</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($car->make); ?></td>
            <td><?php echo e($car->model); ?></td>
            <td><?php echo e($car->doors); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['cars.destroy', $car->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('cars.show', [$car->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('cars.edit', [$car->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\Haris\Desktop\USBWebserver v8.6\root\Laravel\carRent\resources\views/cars/table.blade.php ENDPATH**/ ?>