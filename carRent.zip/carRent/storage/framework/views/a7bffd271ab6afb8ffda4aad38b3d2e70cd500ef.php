<!-- Firstname Field -->
<div class="form-group">
    <?php echo Form::label('firstname', 'Firstname:'); ?>

    <p><?php echo e($customer->firstname); ?></p>
</div>

<!-- Surname Field -->
<div class="form-group">
    <?php echo Form::label('surname', 'Surname:'); ?>

    <p><?php echo e($customer->surname); ?></p>
</div>

<!-- Customertype Field -->
<div class="form-group">
    <?php echo Form::label('customertype', 'Customertype:'); ?>

    <p><?php echo e($customer->customertype); ?></p>
</div>

<!-- Dateofbirth Field -->
<div class="form-group">
    <?php echo Form::label('dateofbirth', 'Dateofbirth:'); ?>

    <p><?php echo e($customer->dateofbirth); ?></p>
</div>

<?php /**PATH C:\Users\Haris\Desktop\USBWebserver v8.6\root\Laravel\carRent\resources\views/customers/show_fields.blade.php ENDPATH**/ ?>