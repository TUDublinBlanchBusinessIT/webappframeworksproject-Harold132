<!-- Make Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('make', 'Make:'); ?>

    <?php echo Form::text('make', null, ['class' => 'form-control']); ?>

</div>

<!-- Model Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('model', 'Model:'); ?>

    <?php echo Form::text('model', null, ['class' => 'form-control']); ?>

</div>

<!-- Doors Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('doors', 'Doors:'); ?>

    <?php echo Form::text('doors', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('cars.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\Users\Haris\Desktop\USBWebserver v8.6\root\Laravel\carRent\resources\views/cars/fields.blade.php ENDPATH**/ ?>