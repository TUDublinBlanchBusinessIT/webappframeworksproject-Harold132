<!-- Bookingdate Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('bookingdate', 'Bookingdate:'); ?>

    <?php echo Form::date('bookingdate', null, ['class' => 'form-control','id'=>'bookingdate']); ?>

</div>



<!-- Starttime Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('starttime', 'Starttime:'); ?>

    <?php echo Form::text('starttime', null, ['class' => 'form-control']); ?>

</div>

<!-- Endtime Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('endtime', 'Endtime:'); ?>

    <?php echo Form::text('endtime', null, ['class' => 'form-control']); ?>

</div>

<!-- Customerid Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('customerid', 'Customerid:'); ?>

    <?php echo Form::number('customerid', null, ['class' => 'form-control']); ?>

</div>

<!-- Carid Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('carid', 'Carid:'); ?>

    <?php echo Form::number('carid', null, ['class' => 'form-control']); ?>

</div>

<!-- Fee Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fee', 'Fee:'); ?>

    <?php echo Form::number('fee', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('bookings.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\Users\Haris\Desktop\USBWebserver v8.6\root\Laravel\carRent\resources\views/bookings/fields.blade.php ENDPATH**/ ?>